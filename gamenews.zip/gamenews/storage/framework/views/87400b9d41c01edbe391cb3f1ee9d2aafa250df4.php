<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center
        bg-light border border-2 p-3 my-4">
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#criarAnotacao">
            Criar Anotação
        </button>

        <!-- Modal -->
        <div class="modal fade" id="criarAnotacao" tabindex="-1" aria-labelledby="criarAnotacaoLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="criarAnotacaoLabel">Criar Anotação</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('create.note')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <label>Título:</label>
                            <input class="form-control" type="text" name="title">
                            <label>Conteúdo:</label>
                            <textarea class="form-control" name="content" cols="30" rows="4"></textarea>
                            <label>Cor:</label>
                            <input class="form-control" type="color" name="color">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-primary">
                                Criar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="d-flex flex-wrap justify-content-around gap-2">
        <?php $__empty_1 = true; $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card border border-2 shadow p-3" style="background-color: <?php echo e($note->color); ?>95;">
                <div class="card-header" style="background-color: <?php echo e($note->color); ?>45;">
                    <?php echo e($note->title); ?>

                </div>
                <div class="card-body">
                    <?php echo e($note->content); ?>

                </div>
                
                <!-- Button trigger modal -->
                <div class="d-flex flex-wrap justify-content-end">
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editar_anotacao"
                    data-bs-note="<?php echo e(json_encode($note)); ?>">
                        Editar
                    </button>
                </div>
                
                <form action="<?php echo e(route('delete.note')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($note->id); ?>">
                    <button class="btn btn-danger" type="submit">Excluir</button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-danger">
                Nenhuma anotação cadastrada!
            </div>
        <?php endif; ?>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="editar_anotacao" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('update.note')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="id">
                        <label>Título:</label>
                        <input class="form-control" type="text" name="title" id="title">
                        <label>Conteúdo:</label>
                        <textarea class="form-control" name="content" cols="30" rows="4" id="content"></textarea>
                        <label>Cor:</label>
                        <input class="form-control" type="color" name="color" id="color">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-success">
                            Editar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const exampleModal = document.getElementById('editar_anotacao')
        exampleModal.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget
            const recipient = button.getAttribute('data-bs-note')
            const note = JSON.parse(recipient);
            document.getElementById('id').value = note.id;
            document.getElementById('title').value = note.title;
            document.getElementById('content').value = note.content;
            document.getElementById('color').value = note.color;
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git\filenote_2\resources\views/dashboard.blade.php ENDPATH**/ ?>