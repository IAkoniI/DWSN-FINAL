<nav class="navbar navbar-expand-lg navbar-light bg-light shadow">
    <div class="container-fluid">
        <?php echo $__env->make('components.application-logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex justify-content-end">
            <a class="dropdown-toggle btn btn-outline-secondary rounded"
                href="#" id="navbarDropdown" role="button"
                data-bs-toggle="dropdown" aria-expanded="false">
                <?php echo e(Auth::user()->name); ?>

            </a>
            <ul class="dropdown-menu dropdown-menu-end"
                aria-labelledby="navbarDropdown">
                <li>
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button class="dropdown-item" type="submit">Sair</button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\Git\filenote_2\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>