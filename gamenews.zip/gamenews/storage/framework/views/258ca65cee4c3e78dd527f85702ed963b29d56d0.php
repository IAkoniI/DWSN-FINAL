<nav class="navbar navbar-expand-lg navbar-light bg-light shadow">
    <div class="container-fluid">
        <?php echo $__env->make('components.application-logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form class="d-flex flex-wrap gap-1" method="get"
            action="<?php echo e(route('dashboard')); ?>">
            <input class="form-control w-auto" type="text" name="search" placeholder="Pesquisar">
            <button class="btn btn-secondary" type="submit">Pesquisar</button>
        </form>

        <!-- Button trigger modal -->
        <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#criarProduto">
            Adicionar notícia
        </button>
        <div class="d-flex justify-content-end">
            <a class="dropdown-toggle btn btn-outline-secondary rounded"
                href="#" id="navbarDropdown" role="button"
                data-bs-toggle="dropdown" aria-expanded="false">
                <?php echo e(Auth::user()->name); ?>

            </a>
            <ul class="dropdown-menu dropdown-menu-end"
                aria-labelledby="navbarDropdown">
                <li>
                    <!-- <a class="dropdown-item" href=""> Editar </a> -->

                    <form method="put" action=" <?php echo e(route('updateLogin', Auth::user()->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <button class="dropdown-item" type="submit">Editar</button>

                    </form>

                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button class="dropdown-item" type="submit">Sair</button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>
<br> <br>
<?php /**PATH C:\Users\nikol\Documents\GitHub\sistema-nied(1)\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>