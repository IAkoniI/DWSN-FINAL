<?php

use App\Http\Controllers\ProdController;
use App\Http\Controllers\EditLoginController;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::get('/dashboard', [ProdController::class, 'dashboard'])
    ->middleware(['auth'])->name('dashboard');

Route::post('adicionar_produto', [ProdController::class, 'create'])
    ->middleware(['auth'])->name('create.prod');

Route::post('editar_produto', [ProdController::class, 'update'])
    ->middleware(['auth'])->name('update.prod');

Route::post('editar_usuario', [ProdController::class, 'update'])
->middleware(['auth'])->name('update.user');

Route::post('excluir_produto', [ProdController::class, 'delete'])
    ->middleware(['auth'])->name('delete.prod');

Route::post('enviar_arquivo', [ProdController::class, 'uploadFile'])
    ->middleware(['auth'])->name('upload.file');

Route::post('exluir_arquivo', [ProdController::class, 'deleteFile'])
    ->middleware(['auth'])->name('delete.file');

Route::post('baixar_arquivo', [ProdController::class, 'downloadFile'])
    ->middleware(['auth'])->name('download.file');

Route::put('/users/{id}', [EditLoginController::class, 'updateLogin'])
    ->name('users.update');

require __DIR__.'/auth.php';
