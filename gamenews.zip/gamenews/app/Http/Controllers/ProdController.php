<?php

namespace App\Http\Controllers;

use App\Models\File;
use App\Models\prod;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class ProdController extends Controller
{
    public function dashboard(Request $request) {
        $prods = prod::where('user_id', Auth::user()->id)
            ->where('title', 'LIKE', '%'.$request->search.'%')
            ->orWhere('desc', 'LIKE', '%'.$request->search.'%')
            ->orderBy('created_at', 'DESC')
            ->paginate(3);
        return view('dashboard', compact('prods'));
    }

    public function create(Request $request) {
        $request->validate([
            'title' => 'required',
            'desc' => 'required',
            'value' => 'required',
           
        ],[
            'required' => 'O campo :attribute é obrigatório!'
        ]);

        $prod = $request->except('_token');
        $prod['user_id'] = Auth::user()->id;
        prod::create($prod);

        return back()->with(['success' => 'Noticia Adicionado com Sucesso!']);
    }

    public function update(Request $request) {
        $request->validate([
            'desc' => 'required',
            'value' => 'required',
           
        ],[
            'required' => 'O campo :attribute é obrigatório!'
        ]);

        $prod = $request->except('_token');

        prod::find($request->id)->update($prod);

        return back()->with(['success' => 'Noticia editado com sucesso!']);
    }

    public function delete(Request $request) {
        // Excluir arquivos relacionados a Noticia
        $files = File::where('prod_id', $request->id)->get();
        foreach ($files as $file) {
            if (Storage::exists($file->directory)) // Verificar se existe o arquivo
                Storage::delete($file->directory); // Excluir arquivo
        }

        prod::find($request->id)->delete();

        return back()->with(['success' => 'Noticia excluída com sucesso!']);
    }

    public function uploadFile(Request $request) {
        $request->validate([
            'id' => 'required | numeric | exists:prods,id',
            'file' => ['required', 'mimes:png,jpg,webp', 'max:1024']
        ],[
            'file.required' => 'Selecione um arquivo!',
            'file.mimes' => 'Os tipos de arquivo permitido é apenas png, jpg ou webp!',
        ]);

        $directory = $request->file->store('files');

        File::create(['prod_id' => $request->id, 'directory' => $directory]);

        return back()->with(['success' => 'Arquivo salvo com sucesso!']);
    }

    public function deleteFile(Request $request) {
        $file = File::find($request->id);

        if (Storage::exists($file->directory)) // Verificar se existe o arquivo
            Storage::delete($file->directory); // Excluir arquivo

        // Ecluir dados na tabela
        $file->delete();

        return back()->with(['success' => 'Arquivo excluído com sucesso!']);
    }

    public function downloadFile(Request $request) {
        $file = File::find($request->id);

        return Storage::download($file->directory);
    }
}
