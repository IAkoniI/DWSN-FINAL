<nav class="navbar navbar-expand-lg navbar-light bg-light shadow">
    <div class="container-fluid">
        @include('components.application-logo')
        <form class="d-flex flex-wrap gap-1" method="get"
            action="{{ route('dashboard') }}">
            <input class="form-control w-auto" type="text" name="search" placeholder="Pesquisar">
            <button class="btn btn-secondary" type="submit">Pesquisar</button>
        </form>

        <!-- Button trigger modal -->
        <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#criarProduto">
            Adicionar notícia
        </button>
        <div class="d-flex justify-content-end">
            <a class="dropdown-toggle btn btn-outline-secondary rounded"
                href="#" id="navbarDropdown" role="button"
                data-bs-toggle="dropdown" aria-expanded="false">
                {{ Auth::user()->name }}
            </a>
            <ul class="dropdown-menu dropdown-menu-end"
                aria-labelledby="navbarDropdown">
                <li>
                    <button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#editar_usuario">
                        Editar 
                    </button>
                   

                    <form action="{{ route('logout') }}" method="post">
                        @csrf
                        <button class="dropdown-item" type="submit">Sair</button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>
<br> <br>
