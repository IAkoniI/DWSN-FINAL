@extends('layouts.app')

@section('content')

     

        <!-- Modal -->
        <div class="modal fade" id="criarProduto" tabindex="-1" aria-labelledby="criarProdutoLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="criarProdutoLabel">Adicionar notícia</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="{{ route('create.prod') }}" method="post">
                        @csrf
                        <div class="modal-body">
                            <label>Título:</label>
                            <input class="form-control" type="text" name="title">
                            <label>Conteúdo:</label>
                            <textarea class="form-control" type="text" name="desc" cols="30" rows="4"></textarea>
                            <label>Autor:</label>
                            <input class="form-control" type="text" name="value">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-primary">
                                Criar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    

    <div class="container">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Sucesso!</strong> {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        {{ $prods->appends(['search' => request()->get('search')])->links('vendor.pagination.bootstrap-4') }}

        <div class="row flex-wrap justify-content-start g-2">
            @forelse($prods as $prod)
                <div class="card border border-2 shadow p-3 col-2 col-md-4 col-lg-4"
                    style="background-color: white 95;">
                    <div class="card-header" style="background-color: white 45;">
                        <label>Título:</label>  {{ $prod->title }}
                    </div>
                    <div class="card-body">
                        <label>Conteúdo:</label>  {{ $prod->desc }}
                    </div>
                    <div class="card-body">
                        <label>Autor:</label>  {{$prod->value }}
                    </div>
                    <div class="border border-1 rounded shadow-sm p-2 mb-2">
                        {{-- Formulário de envio de arquivos --}}
                        <label>Arquivo:</label>
                        <form class="d-flex gap-2"
                            action="{{ route('upload.file', ['id' => $prod->id]) }}"
                            method="post" enctype="multipart/form-data">
                            @csrf
                            <input class="form-control" type="file" name="file">
                            <button class="btn btn-primary">Enviar</button>
                        </form>

                        {{-- Exibir os arquivos --}}
                        <div class="p-2 overflow-auto" style="max-height: 200px;">
                            @forelse ($prod->files as $file)
                                <div class="row g-2 shadow-sm p-2">
                                    <img class="col-10 img-fluid" style="width: 150px; height: 100px;"
                                        src="{{ url('storage/' . $file->directory) }}">
                                    <div class="col-2 d-flex flex-wrap gap-2">
                                        {{-- Baixar arquivo --}}
                                        <form method="post"
                                            action="{{ route('download.file', ['id' => $file->id]) }}">
                                            @csrf
                                            <button class="btn btn-info" type="submit">Baixar</button>
                                        </form>

                                        {{-- Excluir arquivo --}}
                                        <form action="{{ route('delete.file', ['id' => $file->id]) }}" method="post">
                                            @csrf
                                            <button class="btn btn-danger" type="submit">
                                                Excluir
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @empty
                                <div class="">Nenhum arquivo anexado!</div>
                            @endforelse
                        </div>
                    </div>
                    <div class="d-flex flex-wrap gap-2 justify-content-end">
                        {{-- Edição --}}
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editar_produto"
                        data-bs-prod="{{ json_encode($prod) }}">
                            Editar
                        </button>

                        {{-- Exclusão --}}
                        <form action="{{ route('delete.prod', ['id' => $prod->id]) }}" method="post">
                            @csrf
                            <button class="btn btn-danger" type="submit">Excluir</button>
                        </form>
                    </div>
                </div>
            @empty
                <div class="alert alert-danger">
                    Nenhuma notícia cadastrado!
                </div>
            @endforelse
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="editar_produto" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edição de notícias</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="{{ route('update.prod') }}" method="post">
                    @csrf
                    <div class="modal-body">
                        <input type="hidden" name="id" id="id">
                        <label>Título:</label>
                        <input class="form-control" type="text" name="title" id="title">
                        <label>Conteúdo:</label>
                        <textarea class="form-control" name="desc" cols="30" rows="4" id="desc"></textarea>
                        <label>Autor:</label>
                        <input class="form-control" type="text" name="value" id="value">
                
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-success">
                            Editar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

 <!-- <a class="dropdown-item" href=""> Editar </a> -->
 <div class="modal fade" id="editar_usuario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Edição de usuários</h1>
                
            </div>
          
 
<form method="post" action=" {{ route('users.update', Auth::user()->id) }}">
@csrf
@method('PUT')

<div class="modal-body">
    <input type="hidden" name="id" id="id">
    <label>Nome:</label>
    <input class="form-control" type="text" name="name" id="name">
    <label>email:</label>
    <textarea class="form-control" name="email" cols="30" rows="4" id="email"></textarea>
    <label>Senha:</label>
    <input class="form-control" type="text" name="password" id="password">

</div>

</form>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
    <button type="submit" class="btn btn-success">
        Editar</button>
</div>
<!--<button class="dropdown-item" type="submit">Editar</button>-->
            
</div>
</div>
</div>
@endsection

@section('scripts')
    <script>
        const exampleModal = document.getElementById('editar_produto')
        exampleModal.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget
            const recipient = button.getAttribute('data-bs-prod')
            const prod = JSON.parse(recipient);
            document.getElementById('id').value = prod.id;
            document.getElementById('title').value = prod.title;
            document.getElementById('desc').value = prod.desc;
            document.getElementById('value').value = prod.value;
        })
    </script>

<script>
    const exampleModal = document.getElementById('editar_usuario')
    exampleModal.addEventListener('show.bs.modal', event => {
        const button = event.relatedTarget
        const recipient = button.getAttribute('data-bs-users')
        const prod = JSON.parse(recipient);
        document.getElementById('id').value = users.id;
        document.getElementById('name').value = users.title;
        document.getElementById('password').value = users.desc;
    })
</script>
@endsection
