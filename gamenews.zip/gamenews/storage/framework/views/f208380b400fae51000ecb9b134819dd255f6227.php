<?php $__env->startSection('content'); ?>
    <div class="container d-flex flex-wrap gap-2 justify-content-between
        bg-light border border-2 p-3 my-4">
        <form class="d-flex flex-wrap gap-1" method="get"
            action="<?php echo e(route('dashboard')); ?>">
            <input class="form-control w-auto" type="text" name="search" placeholder="Pesquisar">
            <button class="btn btn-secondary" type="submit">Pesquisar</button>
        </form>

        <!-- Button trigger modal -->
        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#criarAnotacao">
            Criar Anotação
        </button>

        <!-- Modal -->
        <div class="modal fade" id="criarAnotacao" tabindex="-1" aria-labelledby="criarAnotacaoLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="criarAnotacaoLabel">Criar Anotação</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('create.note')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <label>Título:</label>
                            <input class="form-control" type="text" name="title">
                            <label>Conteúdo:</label>
                            <textarea class="form-control" name="content" cols="30" rows="4"></textarea>
                            <label>Cor:</label>
                            <input class="form-control" type="color" name="color">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-primary">
                                Criar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Sucesso!</strong> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php echo e($notes->appends(['search' => request()->get('search')])->links('vendor.pagination.bootstrap-4')); ?>


        <div class="row flex-wrap justify-content-start g-2">
            <?php $__empty_1 = true; $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card border border-2 shadow p-3 col-12 col-md-6 col-lg-4"
                    style="background-color: <?php echo e($note->color); ?>95;">
                    <div class="card-header" style="background-color: <?php echo e($note->color); ?>45;">
                        <?php echo e($note->title); ?>

                    </div>
                    <div class="card-body">
                        <?php echo e($note->content); ?>

                    </div>
                    <div class="border border-1 rounded shadow-sm p-2 mb-2">
                        
                        <form class="d-flex gap-2"
                            action="<?php echo e(route('upload.file', ['id' => $note->id])); ?>"
                            method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input class="form-control" type="file" name="file">
                            <button class="btn btn-primary">Enviar</button>
                        </form>

                        
                        <div class="p-2 overflow-auto" style="max-height: 200px;">
                            <?php $__empty_2 = true; $__currentLoopData = $note->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <div class="row g-2 shadow-sm p-2">
                                    <img class="col-10 img-fluid" style="width: 150px; height: 100px;"
                                        src="<?php echo e(url('storage/' . $file->directory)); ?>">
                                    <div class="col-2 d-flex flex-wrap gap-2">
                                        
                                        <form method="post"
                                            action="<?php echo e(route('download.file', ['id' => $file->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-info" type="submit">Baixar</button>
                                        </form>

                                        
                                        <form action="<?php echo e(route('delete.file', ['id' => $file->id])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger" type="submit">
                                                Excluir
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <div class="">Nenhum arquivo anexado!</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap gap-2 justify-content-end">
                        
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editar_anotacao"
                        data-bs-note="<?php echo e(json_encode($note)); ?>">
                            Editar
                        </button>

                        
                        <form action="<?php echo e(route('delete.note', ['id' => $note->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger" type="submit">Excluir</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-danger">
                    Nenhuma anotação cadastrada!
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="editar_anotacao" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('update.note')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="id">
                        <label>Título:</label>
                        <input class="form-control" type="text" name="title" id="title">
                        <label>Conteúdo:</label>
                        <textarea class="form-control" name="content" cols="30" rows="4" id="content"></textarea>
                        <label>Cor:</label>
                        <input class="form-control" type="color" name="color" id="color">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-success">
                            Editar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const exampleModal = document.getElementById('editar_anotacao')
        exampleModal.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget
            const recipient = button.getAttribute('data-bs-note')
            const note = JSON.parse(recipient);
            document.getElementById('id').value = note.id;
            document.getElementById('title').value = note.title;
            document.getElementById('content').value = note.content;
            document.getElementById('color').value = note.color;
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yslan\OneDrive\Desktop\filenote_2\resources\views/dashboard.blade.php ENDPATH**/ ?>