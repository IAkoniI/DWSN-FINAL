<?php $__env->startSection('content'); ?>

     

        <!-- Modal -->
        <div class="modal fade" id="criarProduto" tabindex="-1" aria-labelledby="criarProdutoLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="criarProdutoLabel">Adicionar notícia</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('create.prod')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <label>Título:</label>
                            <input class="form-control" type="text" name="title">
                            <label>Conteúdo:</label>
                            <textarea class="form-control" type="text" name="desc" cols="30" rows="4"></textarea>
                            <label>Autor:</label>
                            <input class="form-control" type="text" name="value">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-primary">
                                Criar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    

    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Sucesso!</strong> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php echo e($prods->appends(['search' => request()->get('search')])->links('vendor.pagination.bootstrap-4')); ?>


        <div class="row flex-wrap justify-content-start g-2">
            <?php $__empty_1 = true; $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card border border-2 shadow p-3 col-2 col-md-4 col-lg-4"
                    style="background-color: white 95;">
                    <div class="card-header" style="background-color: white 45;">
                        <label>Título:</label>  <?php echo e($prod->title); ?>

                    </div>
                    <div class="card-body">
                        <label>Conteúdo:</label>  <?php echo e($prod->desc); ?>

                    </div>
                    <div class="card-body">
                        <label>Autor:</label>  <?php echo e($prod->value); ?>

                    </div>
                    <div class="border border-1 rounded shadow-sm p-2 mb-2">
                        
                        <label>Arquivo:</label>
                        <form class="d-flex gap-2"
                            action="<?php echo e(route('upload.file', ['id' => $prod->id])); ?>"
                            method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input class="form-control" type="file" name="file">
                            <button class="btn btn-primary">Enviar</button>
                        </form>

                        
                        <div class="p-2 overflow-auto" style="max-height: 200px;">
                            <?php $__empty_2 = true; $__currentLoopData = $prod->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <div class="row g-2 shadow-sm p-2">
                                    <img class="col-10 img-fluid" style="width: 150px; height: 100px;"
                                        src="<?php echo e(url('storage/' . $file->directory)); ?>">
                                    <div class="col-2 d-flex flex-wrap gap-2">
                                        
                                        <form method="post"
                                            action="<?php echo e(route('download.file', ['id' => $file->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-info" type="submit">Baixar</button>
                                        </form>

                                        
                                        <form action="<?php echo e(route('delete.file', ['id' => $file->id])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger" type="submit">
                                                Excluir
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <div class="">Nenhum arquivo anexado!</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap gap-2 justify-content-end">
                        
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editar_produto"
                        data-bs-prod="<?php echo e(json_encode($prod)); ?>">
                            Editar
                        </button>

                        
                        <form action="<?php echo e(route('delete.prod', ['id' => $prod->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger" type="submit">Excluir</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-danger">
                    Nenhuma notícia cadastrado!
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="editar_produto" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edição de notícias</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('update.prod')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="id">
                        <label>Título:</label>
                        <input class="form-control" type="text" name="title" id="title">
                        <label>Conteúdo:</label>
                        <textarea class="form-control" name="desc" cols="30" rows="4" id="desc"></textarea>
                        <label>Autor:</label>
                        <input class="form-control" type="text" name="value" id="value">
                
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-success">
                            Editar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

 <!-- <a class="dropdown-item" href=""> Editar </a> -->
 <div class="modal fade" id="editar_usuario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Edição de usuários</h1>
                
            </div>
          
 
<form method="post" action=" <?php echo e(route('users.update', Auth::user()->id)); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<div class="modal-body">
    <input type="hidden" name="id" id="id">
    <label>Nome:</label>
    <input class="form-control" type="text" name="name" id="name">
    <label>email:</label>
    <textarea class="form-control" name="email" cols="30" rows="4" id="email"></textarea>
    <label>Senha:</label>
    <input class="form-control" type="text" name="password" id="password">

</div>

</form>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
    <button type="submit" class="btn btn-success">
        Editar</button>
</div>
<!--<button class="dropdown-item" type="submit">Editar</button>-->
            
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const exampleModal = document.getElementById('editar_produto')
        exampleModal.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget
            const recipient = button.getAttribute('data-bs-prod')
            const prod = JSON.parse(recipient);
            document.getElementById('id').value = prod.id;
            document.getElementById('title').value = prod.title;
            document.getElementById('desc').value = prod.desc;
            document.getElementById('value').value = prod.value;
        })
    </script>

<script>
    const exampleModal = document.getElementById('editar_usuario')
    exampleModal.addEventListener('show.bs.modal', event => {
        const button = event.relatedTarget
        const recipient = button.getAttribute('data-bs-users')
        const prod = JSON.parse(recipient);
        document.getElementById('id').value = users.id;
        document.getElementById('name').value = users.title;
        document.getElementById('password').value = users.desc;
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp3\htdocs\gamenews\resources\views/dashboard.blade.php ENDPATH**/ ?>